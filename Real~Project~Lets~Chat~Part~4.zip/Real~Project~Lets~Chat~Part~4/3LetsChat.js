//YOUR FIREBASE LINKS
const firebaseConfig = {
      apiKey: "AIzaSyA6HG2s68EuVyGHA3PtX-jo37lEvADIuFE",
      authDomain: "lets-chat-6c366.firebaseapp.com",
      databaseURL: "https://lets-chat-6c366-default-rtdb.firebaseio.com",
      projectId: "lets-chat-6c366",
      storageBucket: "lets-chat-6c366.appspot.com",
      messagingSenderId: "306154151344",
      appId: "1:306154151344:web:c1f416d920cebf6c68ca75"
};

firebase.initializeApp(firebaseConfig);

user_name = localStorage.getItem("user_name");
room_name = localStorage.getItem("room_name");

function logout() {
      localStorage.removeItem("user_name");
      localStorage.removeItem("room_name");
      window.location = "1LetsChat.html";
      }

function send() {
     msg = document.getElementById("msg").value;
     console.log("Message - "+msg)
     firebase.database().ref(room_name).push({
      name : user_name,
      message : msg,
      likes : 0
     });

     document.getElementById("msg").innerHTML = "";
}
send()

function getData() { firebase.database().ref("/"+room_name).on('value', function(snapshot) { document.getElementById("output").innerHTML = ""; 
snapshot.forEach(function(childSnapshot) { childKey  = childSnapshot.key; 
childData = childSnapshot.val(); if(childKey != "purpose") {
         firebase_message_id = childKey;
         message_data = childData;
//Start code
console.log("Room Name - "+ Room_names);
console.log(firebase_message_id);
console.log(message_data);

name=message_data['name'];
message=message_data['message'];
likes=message_data['likes'];

display_name = "<h4>"+ name + "<img class='user_tick' src='tick.png'> </h4>";
display_message = "<h4 class='message_h4'>"+ message +"</h4>";
button = "<button class='btn btn-warning' id="+firebase_message_id+"value="+likes+"onclick='update_likes(this.id)'>";
thumbs_up = "<span class='glyphicon glyphicon-thumbs-up'> Likes : "+ likes + "</span></button><hr>";

row = display_name + display_message + button + thumbs_up;

document.getElementById("output").innerHTML += row;
//End code
      } });  }); }
getData();

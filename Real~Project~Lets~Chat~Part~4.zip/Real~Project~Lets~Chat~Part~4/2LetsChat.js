const firebaseConfig = {
  apiKey: "AIzaSyA6HG2s68EuVyGHA3PtX-jo37lEvADIuFE",
  authDomain: "lets-chat-6c366.firebaseapp.com",
  databaseURL: "https://lets-chat-6c366-default-rtdb.firebaseio.com",
  projectId: "lets-chat-6c366",
  storageBucket: "lets-chat-6c366.appspot.com",
  messagingSenderId: "306154151344",
  appId: "1:306154151344:web:c1f416d920cebf6c68ca75"
};

firebase.initializeApp(firebaseConfig);

localStorage.setItem("user_name", user_name);
user_name = localStorage.getItem("user_name");

document.getElementById("welcome_message").innerHTML = "Welcome " + user_name + "!";

function logout() {
  localStorage.removeItem("user_name");
  localStorage.removeItem("room_name");
  window.location = "1LetsChat.html";
  }

  function addRoom() {
    room_name = document.getElementById("room_name").value;
    firebase.database().ref("/").child(room_name).update({
      purpose : "adding Room"
   });   

    localStorage.setItem("room_name", room_name);

    document.getElementById("room_name").innerHTML = "";

    window.location = "3LetsChat.html";
 } 

 function getData() {
  firebase.database().ref("/").on('value', function(snapshot) {
  document.getElementById("output").innerHTML = "";
  snapshot.forEach(function(childSnapshot) {
  childKey  = childSnapshot.key;
  Room_names = childKey;
  console.log("Room Name - "+ Room_names);
  });});}
getData();

function redirectToRoomName(name_room) {
  console.log(name_room);
  localStorage.setItem("room_name", name_room);
  window.location = "3LetsChat.html";
}